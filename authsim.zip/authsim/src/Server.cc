//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//void Server::initialize()
//{
//    processDoneMsg  = new cMessage("processDone");
//    processDoneMsg3 = new cMessage("processDone3");
//}
//
//
//
//void Server::handleMessage(cMessage *msg)
//{
//    // ��� 1��t1 ������ɣ��� Msg2
//    if (msg == processDoneMsg) {
//        Msg2 *resp = new Msg2("AuthChallenge");
//        resp->setPayloadBits(128);
//        resp->setBitLength(128);
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ��� 2��t3 ������ɣ��� Msg4
//    if (msg == processDoneMsg3) {
//        Msg4 *resp = new Msg4("AuthSuccess");
//        resp->setPayloadBits(64);
//        resp->setBitLength(64);
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ��� 3���յ� Msg1
//    if (dynamic_cast<Msg1 *>(msg)) {
//        EV << "Server received Msg1, start processing..." << endl;
//        scheduleAt(simTime() + SimTime(5, SIMTIME_MS), processDoneMsg);
//        delete msg;
//        return;
//    }
//
//    // ��� 4���յ� Msg3
//    if (dynamic_cast<Msg3 *>(msg)) {
//        EV << "Server received Msg3, start processing..." << endl;
//        scheduleAt(simTime() + SimTime(4, SIMTIME_MS), processDoneMsg3);
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}
//
//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//void Server::initialize() {
//    processDoneMsg  = new cMessage("processDone");
//    processDoneMsg3 = new cMessage("processDone3");
//}
//
//void Server::handleMessage(cMessage *msg) {
//    // ��� 1��t1 ������ɣ��� Msg2
//    if (msg == processDoneMsg) {
//        Msg2 *resp = new Msg2("AuthChallenge");
//        resp->setPayloadBits(1184);  // ���� Msg2 ��СΪ1184 bits
//        resp->setBitLength(1184);    // ���� Msg2 �ı��س���Ϊ1184
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ��� 2��t3 ������ɣ��� Msg4
//    if (msg == processDoneMsg3) {
//        Msg4 *resp = new Msg4("AuthSuccess");
//        resp->setPayloadBits(192);   // ���� Msg4 ��СΪ192 bits
//        resp->setBitLength(192);     // ���� Msg4 �ı��س���Ϊ192
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ��� 3���յ� Msg1����֤����
//    if (dynamic_cast<Msg1 *>(msg)) {
//        EV << "Server received Msg1, start processing..." << endl;
//        scheduleAt(simTime() + (long long)(0.691 * 1000), processDoneMsg);  // �ӳ�0.691ms
//        delete msg;
//        return;
//    }
//
//    // ��� 4���յ� Msg3����֤��Ӧ��
//    if (dynamic_cast<Msg3 *>(msg)) {
//        EV << "Server received Msg3, start processing..." << endl;
//        scheduleAt(simTime() + (long long)(0.698 * 1000), processDoneMsg3);  // �ӳ�0.698ms
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}
//=======================================================================================
//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//void Server::initialize()
//{
//    processDoneMsg  = new cMessage("processDone");
//    processDoneMsg3 = new cMessage("processDone3");
//}
//
//void Server::handleMessage(cMessage *msg)
//{
//    // ��� 1�������� Msg1 �󣬷��� Msg2
//    if (msg == processDoneMsg) {
//        Msg2 *resp = new Msg2("AuthChallenge");
//        resp->setPayloadBits(1184);  // ���� Msg2 �Ĵ�С
//        resp->setBitLength(1184);    // ���� Msg2 �ı��س���
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ��� 2�������� Msg3 �󣬷��� Msg4
//    if (msg == processDoneMsg3) {
//        Msg4 *resp = new Msg4("AuthSuccess");
//        resp->setPayloadBits(192);   // ���� Msg4 �Ĵ�С
//        resp->setBitLength(192);     // ���� Msg4 �ı��س���
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ��� 3���յ� Msg1
//    if (dynamic_cast<Msg1 *>(msg)) {
//        EV << "Server received Msg1, start processing..." << endl;
//        scheduleAt(simTime() + SimTime(0.691, SIMTIME_MS), processDoneMsg);
//        delete msg;
//        return;
//    }
//
//    // ��� 4���յ� Msg3
//    if (dynamic_cast<Msg3 *>(msg)) {
//        EV << "Server received Msg3, start processing..." << endl;
//        scheduleAt(simTime() + SimTime(0.698, SIMTIME_MS), processDoneMsg3);
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}
//================================================================================
//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//void Server::initialize()
//{
//    processDoneMsg  = new cMessage("processDone");
//    processDoneMsg3 = new cMessage("processDoneMsg3");
//}
//
//void Server::handleMessage(cMessage *msg)
//{
//    // ��� 1���յ� Msg1 �󣬴��������� Msg2
//    if (dynamic_cast<Msg1 *>(msg)) {
//        EV << "Server received Msg1, start processing..." << endl;
//        scheduleAt(simTime() + SimTime(0.691, SIMTIME_MS), processDoneMsg);
//        delete msg;
//        return;
//    }
//
//    // ��� 2���յ� Msg3 �󣬴��������� Msg4
//    if (dynamic_cast<Msg3 *>(msg)) {
//        EV << "Server received Msg3, start processing..." << endl;
//        scheduleAt(simTime() + SimTime(0.698, SIMTIME_MS), processDoneMsg3);
//        delete msg;
//        return;
//    }
//
//    // ��� 3��������� Msg3������ Msg4
//    if (msg == processDoneMsg3) {
//        Msg4 *resp = new Msg4("AuthSuccess");
//        resp->setPayloadBits(192);   // ���� Msg4 �Ĵ�С
//        resp->setBitLength(192);     // ���� Msg4 �ı��س���
//        send(resp, "radio$o");
//        EV << "Server processed Msg3 and sending Msg4 to device." << endl;
//        return;
//    }
//
//    delete msg;
//}
//==========================================4����Ϣ���=================================================
//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//// ���캯������ʼ��ָ��Ϊ�գ���ֹ����
//Server::Server() {
//    processDoneMsg = nullptr;
//    processDoneMsg3 = nullptr;
//}
//
//// �����������������ʱ�����ڴ棬��ֹ�ڴ�й©
//Server::~Server() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(processDoneMsg3);
//}
//
//void Server::initialize() {
//    // ������������Ϣ�����ӣ�
//    processDoneMsg = new cMessage("serverProcessDone1");
//    processDoneMsg3 = new cMessage("serverProcessDone3");
//}
//
//void Server::handleMessage(cMessage *msg) {
//    // --- ���� 1���յ������豸�� Msg1 ---
//    if (dynamic_cast<Msg1 *>(msg)) {
//        EV << "Server: �յ� Msg1����ʼ���� (0.691ms)..." << endl;
//        delete msg; // �յ�������ԭ��Ϣ
//        // �趨���ӣ�0.691ms ��ִ����һ��
//        scheduleAt(simTime() + SimTime(0.691, SIMTIME_MS), processDoneMsg);
//        return;
//    }
//
//    // --- ���� 2������ Msg1 ��ϵġ����ӡ����� ---
//    if (msg == processDoneMsg) {
//        EV << "Server: Msg1 ������ϣ����ڷ��� Msg2..." << endl;
//        Msg2 *resp = new Msg2("AuthMsg2");
//        resp->setBitLength(1184); // ������Ϣ���س���
//        send(resp, "radio$o");     // �����豸
//        return;
//    }
//
//    // --- ���� 3���յ������豸�� Msg3 ---
//    if (dynamic_cast<Msg3 *>(msg)) {
//        EV << "Server: �յ� Msg3����ʼ���� (0.698ms)..." << endl;
//        delete msg;
//        // �趨���ӣ�0.698ms ��ִ����һ��
//        scheduleAt(simTime() + SimTime(0.698, SIMTIME_MS), processDoneMsg3);
//        return;
//    }
//
//    // --- ���� 4������ Msg3 ��ϵġ����ӡ����� ---
//    if (msg == processDoneMsg3) {
//        EV << "Server: Msg3 ������ϣ���֤�ɹ������� Msg4..." << endl;
//        Msg4 *resp = new Msg4("AuthSuccess");
//        resp->setBitLength(192);
//        send(resp, "radio$o");
//        return;
//    }
//
//    // ����յ�������Ϣ��ֱ��ɾ��
//    delete msg;
//}
//======================================���붪���ʼ���===========================================================
//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//Server::Server() {
//    processDoneMsg = nullptr;
//    processDoneMsg3 = nullptr;
//}
//
//Server::~Server() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(processDoneMsg3);
//}
//
//bool Server::shouldDrop() {
//    return uniform(0, 1) < lossProb;
//}
//
//void Server::initialize() {
//    processDoneMsg  = new cMessage("serverProcessDone1");
//    processDoneMsg3 = new cMessage("serverProcessDone3");
//
//    lossProb = par("lossProb").doubleValue();
//
//    msgTxAttempts = 0;
//    msgDropped = 0;
//}
//
//void Server::handleMessage(cMessage *msg) {
//
//    // receive Msg1
//    if (dynamic_cast<Msg1 *>(msg)) {
//
//        // drop on receive
//        if (shouldDrop()) {
//            msgDropped++;
//            delete msg;
//            return;
//        }
//
//        delete msg;
//
//        // 0.691ms = 691us
//        scheduleAt(simTime() + SimTime(691, SIMTIME_US), processDoneMsg);
//        return;
//    }
//
//    // send Msg2
//    if (msg == processDoneMsg) {
//
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            return;
//        }
//
//        Msg2 *resp = new Msg2("AuthMsg2");
//        resp->setBitLength(1184);
//        send(resp, "radio$o");
//        return;
//    }
//
//    // receive Msg3
//    if (dynamic_cast<Msg3 *>(msg)) {
//
//        if (shouldDrop()) {
//            msgDropped++;
//            delete msg;
//            return;
//        }
//
//        delete msg;
//
//        // 0.698ms = 698us
//        scheduleAt(simTime() + SimTime(698, SIMTIME_US), processDoneMsg3);
//        return;
//    }
//
//    // send Msg4
//    if (msg == processDoneMsg3) {
//
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            return;
//        }
//
//        Msg4 *resp = new Msg4("AuthSuccess");
//        resp->setBitLength(192);
//        send(resp, "radio$o");
//        return;
//    }
//
//    delete msg;
//}

//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//Server::Server() {
//    processDoneMsg = nullptr;
//    processDoneMsg3 = nullptr;
//}
//
//Server::~Server() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(processDoneMsg3);
//}
//
//bool Server::shouldDrop() {
//    return uniform(0, 1) < lossProb;
//}
//
//void Server::initialize() {
//    processDoneMsg  = new cMessage("serverProcessDone1");
//    processDoneMsg3 = new cMessage("serverProcessDone3");
//
//    lossProb = par("lossProb").doubleValue();
//    msgTxAttempts = 0;
//    msgDropped = 0;
//}
//
//void Server::handleMessage(cMessage *msg) {
//
//    // receive Msg1
//    if (dynamic_cast<Msg1 *>(msg)) {
//
//        if (shouldDrop()) {
//            msgDropped++;
//            delete msg;
//            return;
//        }
//
//        delete msg;
//
//        // processing time: 0.691ms = 0.000691s
//        scheduleAt(simTime() + SimTime(0.000691, SIMTIME_S), processDoneMsg);
//        return;
//    }
//
//    // send Msg2
//    if (msg == processDoneMsg) {
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            return;
//        }
//
//        Msg2 *m2 = new Msg2("AuthMsg2");
//        m2->setBitLength(1184);
//        send(m2, "radio$o");
//        return;
//    }
//
//    // receive Msg3
//    if (dynamic_cast<Msg3 *>(msg)) {
//
//        if (shouldDrop()) {
//            msgDropped++;
//            delete msg;
//            return;
//        }
//
//        delete msg;
//
//        // processing time: 0.698ms = 0.000698s
//        scheduleAt(simTime() + SimTime(0.000698, SIMTIME_S), processDoneMsg3);
//        return;
//    }
//
//    // send Msg4
//    if (msg == processDoneMsg3) {
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            return;
//        }
//
//        Msg4 *m4 = new Msg4("AuthSuccess");
//        m4->setBitLength(192);
//        send(m4, "radio$o");
//        return;
//    }
//
//    delete msg;
//}
//====================================����s=============================
//#include "Server.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Server);
//
//Server::Server() {
//    processDoneMsg = nullptr;
//    processDoneMsg3 = nullptr;
//}
//
//Server::~Server() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(processDoneMsg3);
//}
//
//bool Server::shouldDrop() {
//    return uniform(0, 1) < lossProb;
//}
//
//void Server::initialize() {
//    processDoneMsg  = new cMessage("serverProcessDone1");
//    processDoneMsg3 = new cMessage("serverProcessDone3");
//
//    lossProb = par("lossProb").doubleValue();
//    msgTxAttempts = 0;
//    msgDropped = 0;
//}
//
//void Server::handleMessage(cMessage *msg) {
//
//    // receive Msg1
//    if (dynamic_cast<Msg1 *>(msg)) {
//
//        if (shouldDrop()) {
//            msgDropped++;
//            delete msg;
//            return;
//        }
//
//        delete msg;
//
//        // processing time: 0.691ms = 0.000691s
//        scheduleAt(simTime() + SimTime(0.000691, SIMTIME_S), processDoneMsg);
//        return;
//    }
//
//    // send Msg2
//    if (msg == processDoneMsg) {
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            return;
//        }
//
//        Msg2 *m2 = new Msg2("AuthMsg2");
//        m2->setBitLength(1184);
//        send(m2, "radio$o");
//        return;
//    }
//
//    // receive Msg3
//    if (dynamic_cast<Msg3 *>(msg)) {
//
//        if (shouldDrop()) {
//            msgDropped++;
//            delete msg;
//            return;
//        }
//
//        delete msg;
//
//        // processing time: 0.698ms = 0.000698s
//        scheduleAt(simTime() + SimTime(0.000698, SIMTIME_S), processDoneMsg3);
//        return;
//    }
//
//    // send Msg4
//    if (msg == processDoneMsg3) {
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            return;
//        }
//
//        Msg4 *m4 = new Msg4("AuthSuccess");
//        m4->setBitLength(192);
//        send(m4, "radio$o");
//        return;
//    }
//
//    delete msg;
//}
//============================�����������=========================
#include "Server.h"
#include "AuthMessages_m.h"

Define_Module(Server);

Server::Server() {
    processDoneMsg = nullptr;
    processDoneMsg3 = nullptr;
}

Server::~Server() {
    cancelAndDelete(processDoneMsg);
    cancelAndDelete(processDoneMsg3);
}

void Server::initialize() {
    processDoneMsg  = new cMessage("serverProcessDone1");
    processDoneMsg3 = new cMessage("serverProcessDone3");
}

void Server::handleMessage(cMessage *msg) {

    // receive Msg1
    if (dynamic_cast<Msg1 *>(msg)) {
        delete msg;

        // 0.691ms = 0.000691s
        scheduleAt(simTime() + SimTime(0.000691), processDoneMsg);
        return;
    }

    // send Msg2
    if (msg == processDoneMsg) {
        Msg2 *m2 = new Msg2("AuthMsg2");
        m2->setBitLength(1184);
        send(m2, "radio$o");
        return;
    }

    // receive Msg3
    if (dynamic_cast<Msg3 *>(msg)) {
        delete msg;

        // 0.698ms = 0.000698s
        scheduleAt(simTime() + SimTime(0.000698), processDoneMsg3);
        return;
    }

    // send Msg4
    if (msg == processDoneMsg3) {
        Msg4 *m4 = new Msg4("AuthSuccess");
        m4->setBitLength(192);
        send(m4, "radio$o");
        return;
    }

    delete msg;
}











