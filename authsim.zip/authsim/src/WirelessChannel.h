#ifndef __WIRELESSCHANNEL_H
#define __WIRELESSCHANNEL_H

#include <omnetpp.h>
#include <vector>

using namespace omnetpp;

class WirelessChannel : public cSimpleModule
{
  public:
    WirelessChannel();
    virtual ~WirelessChannel();

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

  private:
    struct Tx {
        simtime_t start;
        simtime_t end;          // end of on-air transmission (no propagation)
        int senderIndex;        // which gate index sent it
        bool collided;          // collision happened?
        cPacket *frame;         // the frame (packet)
        cMessage *endEvent;     // self-message fired at end + propagationDelay
    };

    double bitrate;            // bps
    simtime_t propagationDelay;

    std::vector<Tx*> ongoing;

  private:
    simtime_t calcTxDuration(cPacket *pkt) const;
    void checkCollisionAndMark(Tx *newTx);
    void finishTransmission(Tx *tx);
};

#endif
