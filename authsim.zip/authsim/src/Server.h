//#ifndef __AUTHSIM_SERVER_H
//#define __AUTHSIM_SERVER_H
//
//#include <omnetpp.h>
//
//using namespace omnetpp;
//
////class Server : public cSimpleModule
////{
////  protected:
////    cMessage *processDoneMsg;
////    cMessage *processDoneMsg3;
////
////    virtual void initialize() override;
////    virtual void handleMessage(cMessage *msg) override;
////};
//class Server : public cSimpleModule
//{
//  private:
//    cMessage *processDoneMsg;  // ���� Msg1 ������
//    cMessage *processDoneMsg3; // ���� Msg3 ������
//
//  protected:
//    virtual void initialize() override;
//    virtual void handleMessage(cMessage *msg) override;
//
//  public:
//    Server();
//    virtual ~Server();
//};
//
//
//
//#endif
//================================���붪���ʼ���==============================
#ifndef __SERVER_H
#define __SERVER_H

#include <omnetpp.h>

using namespace omnetpp;

class Server : public cSimpleModule
{
  public:
    Server();
    virtual ~Server();

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

  private:
    cMessage *processDoneMsg;
    cMessage *processDoneMsg3;

    // stats
    long msgTxAttempts;
    long msgDropped;

    double lossProb;

  private:
    bool shouldDrop();
};

#endif
