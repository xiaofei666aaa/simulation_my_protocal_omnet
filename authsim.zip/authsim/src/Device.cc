//#include "Device.h"
//#include "AuthMessages_m.h"
//simtime_t authStartTime;
//
//
//Define_Module(Device);
//
//void Device::initialize()
//{
//    // 用于表示“Device 处理完成”的自消息
//    processDoneMsg = new cMessage("deviceProcessDone");
//
//    authStartTime = simTime();   // 记录认证开始时间
//    // 创建并发送 Msg1（你之前已经写过）
//    Msg1 *msg = new Msg1("AuthRequest");
//    msg->setPayloadBits(256);
//    msg->setBitLength(256);
//
//    send(msg, "radio$o");
//}
//
//
//
//void Device::handleMessage(cMessage *msg)
//{
//    // 情况 0：收到认证成功 Msg4
//    if (dynamic_cast<Msg4 *>(msg)) {
//        simtime_t delay = simTime() - authStartTime;
//        EV << "Authentication completed, delay = " << delay << endl;
//        delete msg;
//        return;
//    }
//
//    // 情况 1：Device 的处理完成自消息
//    if (msg == processDoneMsg) {
//        // 处理完成，发送 Msg3
//        Msg3 *req = new Msg3("AuthResponse");
//        req->setPayloadBits(256);
//        req->setBitLength(256);
//
//        send(req, "radio$o");
//        return;
//    }
//
//    // 情况 2：收到 Server 发来的 Msg2
//    if (dynamic_cast<Msg2 *>(msg)) {
//        EV << "Device received Msg2, start processing..." << endl;
//
//        // 模拟处理时间 t2（先写死 3ms）
//        scheduleAt(simTime() + SimTime(3, SIMTIME_MS), processDoneMsg);
//
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}




//
//#include "Device.h"
//#include "AuthMessages_m.h"
//simtime_t authStartTime;
//
//Define_Module(Device);
//
//void Device::initialize() {
//    // 用于表示“Device 处理完成”的自消息
//    processDoneMsg = new cMessage("deviceProcessDone");
//
//    authStartTime = simTime();   // 记录认证开始时间
//
//    // 发送第一个消息：AuthRequest（消息1）
//    Msg1 *msg = new Msg1("AuthRequest");
//    msg->setPayloadBits(1216);  // 设置 Msg1 大小为1216 bits
//    msg->setBitLength(1216);    // 设置 Msg1 的比特长度为1216
//    send(msg, "radio$o");       // 发送消息1
//    EV << "Device sent AuthRequest" << endl;
//
//    // 发送第一个延迟事件，t1 = 0.691ms
//    scheduleAt(simTime() + SimTime(0.691, SIMTIME_MS), processDoneMsg); // 转换为ms
//}
//
//void Device::handleMessage(cMessage *msg) {
//    // 处理 Msg2（认证挑战）
//    if (dynamic_cast<Msg2 *>(msg)) {
//        Msg2 *msg2 = check_and_cast<Msg2 *>(msg);
//        msg2->setPayloadBits(1184);  // 设置 Msg2 消息大小为1184 bits
//        msg2->setBitLength(1184);    // 设置 Msg2 的比特长度为1184
//        EV << "Device received Msg2, start processing..." << endl;
//
//        // 如果 processDoneMsg 已经调度，先取消它
//        if (processDoneMsg->isScheduled()) {
//            cancelEvent(processDoneMsg);
//        }
//
//        // 输出调度日志
//        EV << "Scheduling processDoneMsg at " << simTime() + 20.892 << endl;
//        scheduleAt(simTime() + (long long)(20.892 * 1000), processDoneMsg);  // 延迟20.892ms
//        return;
//    }
//
//    // 处理 Msg4（认证成功）
//    else if (dynamic_cast<Msg4 *>(msg)) {
//        Msg4 *msg4 = check_and_cast<Msg4 *>(msg);
//        msg4->setPayloadBits(192);   // 设置 Msg4 消息大小为192 bits
//        msg4->setBitLength(192);     // 设置 Msg4 的比特长度为192
//        EV << "Device received Msg4, start processing..." << endl;
//
//        // 如果 processDoneMsg 已经调度，先取消它
//        if (processDoneMsg->isScheduled()) {
//            cancelEvent(processDoneMsg);
//        }
//
//        // 输出调度日志
//        EV << "Scheduling processDoneMsg at " << simTime() + 0.01 << endl;
//        scheduleAt(simTime() + (long long)(0.01 * 1000), processDoneMsg);  // 延迟0.01ms
//    }
//
//    delete msg;  // 删除处理过的消息
//}

//#include "Device.h"
//#include "AuthMessages_m.h"
//simtime_t authStartTime;
//
//Define_Module(Device);
//
//void Device::initialize()
//{
//    // 用于表示“Device 处理完成”的自消息
//    processDoneMsg = new cMessage("deviceProcessDone");
//
//    authStartTime = simTime();   // 记录认证开始时间
//    // 创建并发送 Msg1
//    Msg1 *msg = new Msg1("AuthRequest");
//    msg->setPayloadBits(1216);  // 设置 Msg1 的大小
//    msg->setBitLength(1216);    // 设置 Msg1 的比特长度
//
//    // 发送 Msg1 到 "radio$o"（无线接口）
//    send(msg, "radio$o");
//
//    EV << "Device initialized and Msg1 sent to server." << endl;
//}
//
//void Device::handleMessage(cMessage *msg)
//{
//    // 情况 0：收到认证成功 Msg4
//    if (dynamic_cast<Msg4 *>(msg)) {
//        simtime_t delay = simTime() - authStartTime;
//        EV << "Authentication completed, delay = " << delay << endl;
//        delete msg;
//        return;
//    }
//
//    // 情况 1：Device 的处理完成自消息
//    if (msg == processDoneMsg) {
//        // 处理完成，发送 Msg3
//        Msg3 *req = new Msg3("AuthResponse");
//        req->setPayloadBits(1376); // 设置 Msg3 的大小
//        req->setBitLength(1376);   // 设置 Msg3 的比特长度
//
//        send(req, "radio$o");
//        return;
//    }
//
//    // 情况 2：收到 Server 发来的 Msg2
//    if (dynamic_cast<Msg2 *>(msg)) {
//        EV << "Device received Msg2, start processing..." << endl;
//
//        // 模拟处理时间 t2（设为 20.892ms）
//        scheduleAt(simTime() + SimTime(20.892, SIMTIME_MS), processDoneMsg);
//
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}
//==========================================================================================
//#include "Device.h"
//#include "AuthMessages_m.h"
//simtime_t authStartTime;
//
//Define_Module(Device);
//
//void Device::initialize()
//{
//    // 用于表示“Device 处理完成”的自消息
//    processDoneMsg = new cMessage("deviceProcessDone");
//
//    authStartTime = simTime();   // 记录认证开始时间
//
//    // 添加延迟 10.045ms 来模拟设备生成 Msg1 的时间
//    scheduleAt(simTime() + SimTime(10.045, SIMTIME_MS), processDoneMsg);
//}
//
//void Device::handleMessage(cMessage *msg)
//{
//    // 情况 0：收到认证成功 Msg4
//    if (dynamic_cast<Msg4 *>(msg)) {
//        simtime_t delay = simTime() - authStartTime;
//        EV << "Authentication completed, delay = " << delay << endl;
//        delete msg;
//        return;
//    }
//
//    // 情况 1：Device 的处理完成自消息
//    if (msg == processDoneMsg) {
//        // 处理完成后，发送 Msg1 给服务器
//        Msg1 *msg = new Msg1("AuthRequest");
//        msg->setPayloadBits(1216);  // 设置 Msg1 的大小
//        msg->setBitLength(1216);    // 设置 Msg1 的比特长度
//
//        send(msg, "radio$o");  // 发送 Msg1 到 "radio$o"（无线接口）
//        EV << "Device initialized and Msg1 sent to server after delay." << endl;
//        return;
//    }
//
//    // 情况 2：收到 Server 发来的 Msg2
//    if (dynamic_cast<Msg2 *>(msg)) {
//        EV << "Device received Msg2, start processing..." << endl;
//
//        // 模拟处理时间 t2（设为 20.892ms）
//        scheduleAt(simTime() + SimTime(20.892, SIMTIME_MS), processDoneMsg);
//
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}
//====================================================================================
//#include "Device.h"
//#include "AuthMessages_m.h"
//simtime_t authStartTime;
//
//Define_Module(Device);
//
//void Device::initialize()
//{
//    // 用于表示“Device 处理完成”的自消息
//    processDoneMsg = new cMessage("deviceProcessDone");
//
//    authStartTime = simTime();   // 记录认证开始时间
//
//    // 添加延迟 10.045ms 来模拟设备生成 Msg1 的时间
//    scheduleAt(simTime() + SimTime(10.045, SIMTIME_MS), processDoneMsg); // 发送 Msg1 前的延迟
//    EV << "Device initialized, waiting to send Msg1." << endl;
//}
//
//void Device::handleMessage(cMessage *msg)
//{
//    // 情况 0：收到认证成功 Msg4
//    if (dynamic_cast<Msg4 *>(msg)) {
//        simtime_t delay = simTime() - authStartTime;
//        EV << "Authentication completed, delay = " << delay << endl;
//        delete msg;
//        return;
//    }
//
//    // 情况 1：Device 的处理完成自消息，发送 Msg1
//    if (msg == processDoneMsg) {
//        // 处理完成后，发送 Msg1 给服务器
//        Msg1 *msg = new Msg1("AuthRequest");
//        msg->setPayloadBits(1216);  // 设置 Msg1 的大小
//        msg->setBitLength(1216);    // 设置 Msg1 的比特长度
//
//        send(msg, "radio$o");  // 发送 Msg1 到 "radio$o"（无线接口）
//        EV << "Device processed Msg1 and sent to server." << endl;
//        return;
//    }
//
//    // 情况 2：收到 Server 发来的 Msg2
//    if (dynamic_cast<Msg2 *>(msg)) {
//        EV << "Device received Msg2, start processing..." << endl;
//
//        // 模拟处理时间 t2（设为 20.892ms）
//        scheduleAt(simTime() + SimTime(20.892, SIMTIME_MS), processDoneMsg); // 调度处理 Msg2 后的动作
//
//        delete msg;
//        return;
//    }
//
//    // 情况 3：设备完成 Msg2 处理，发送 Msg3
//    if (msg == processDoneMsg) {
//        // 处理完成后，发送 Msg3
//        Msg3 *msg3 = new Msg3("AuthResponse");
//        msg3->setPayloadBits(1376);  // 设置 Msg3 的大小
//        msg3->setBitLength(1376);    // 设置 Msg3 的比特长度
//
//        send(msg3, "radio$o");  // 发送 Msg3 到 "radio$o"（无线接口）
//        EV << "Device processed Msg2 and sending Msg3 to server." << endl;
//        return;
//    }
//
//    delete msg;
//}
//======================4个消息完成================================
//#include "Device.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Device);
//
//Device::Device() {
//    processDoneMsg = nullptr;
//    sendMsg3Timer = nullptr;
//}
//
//Device::~Device() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(sendMsg3Timer);
//}
//
//void Device::initialize() {
//    authStartTime = simTime(); // 记录开始认证的时间点
//
//    // 初始化自消息
//    processDoneMsg = new cMessage("deviceInitDone");
//    sendMsg3Timer = new cMessage("deviceSendMsg3");
//
//    // 步骤 1：设备启动延迟 (10.045ms)
//    EV << "Device: 正在初始化，10.045ms 后发送 Msg1..." << endl;
//    scheduleAt(simTime() + SimTime(10.045, SIMTIME_MS), processDoneMsg);
//}
//
//void Device::handleMessage(cMessage *msg) {
//    // --- 步骤 2：初始化“闹钟”响了，发送 Msg1 ---
//    if (msg == processDoneMsg) {
//        EV << "Device: 初始化完成，发送 Msg1。" << endl;
//        Msg1 *m1 = new Msg1("AuthRequest");
//        m1->setBitLength(1216);
//        send(m1, "radio$o");
//        return;
//    }
//
//    // --- 步骤 3：收到服务器发来的 Msg2 ---
//    if (dynamic_cast<Msg2 *>(msg)) {
//        EV << "Device: 收到 Msg2，开始处理 (20.892ms)..." << endl;
//        delete msg;
//        // 设定闹钟，20.892ms 后发送 Msg3
//        scheduleAt(simTime() + SimTime(20.892, SIMTIME_MS), sendMsg3Timer);
//        return;
//    }
//
//    // --- 步骤 4：处理 Msg2 完毕的“闹钟”响了 ---
//    if (msg == sendMsg3Timer) {
//        EV << "Device: Msg2 处理完毕，正在发送 Msg3..." << endl;
//        Msg3 *m3 = new Msg3("AuthResponse");
//        m3->setBitLength(1376);
//        send(m3, "radio$o");
//        return;
//    }
//
//    // --- 步骤 5：收到 Msg4，大功告成 ---
//    if (dynamic_cast<Msg4 *>(msg)) {
//        simtime_t totalDelay = simTime() - authStartTime;
//        EV << "Device: !!! 收到 Msg4，认证圆满成功 !!!" << endl;
//        EV << "Device: 总延迟 (Total Delay) = " << totalDelay << "s" << endl;
//        delete msg;
//        return;
//    }
//
//    delete msg;
//}
//=========================4个消息认证完成且开始循环=======================
//#include "Device.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Device);
//
//Device::Device() {
//    processDoneMsg = nullptr;
//    sendMsg3Timer = nullptr;
//}
//
//Device::~Device() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(sendMsg3Timer);
//}
//
//void Device::initialize() {
//    processDoneMsg = new cMessage("deviceInitDone");
//    sendMsg3Timer = new cMessage("deviceSendMsg3");
//
//    // 第一次认证开始
//    authStartTime = simTime();
//    scheduleAt(simTime() + SimTime(10.045, SIMTIME_MS), processDoneMsg);
//}
//
//void Device::handleMessage(cMessage *msg) {
//    // --- 阶段 1：发送 Msg1 ---
//    if (msg == processDoneMsg) {
//        authStartTime = simTime(); // 每次开始认证时重置开始时间，方便计算单次延迟
//        EV << "Device: 开始新的认证周期，发送 Msg1。" << endl;
//        Msg1 *m1 = new Msg1("AuthRequest");
//        m1->setBitLength(1216);
//        send(m1, "radio$o");
//    }
//
//    // --- 阶段 2：收到 Msg2，处理并准备发 Msg3 ---
//    else if (dynamic_cast<Msg2 *>(msg)) {
//        EV << "Device: 收到 Msg2，处理中 (20.892ms)..." << endl;
//        delete msg;
//        scheduleAt(simTime() + SimTime(20.892, SIMTIME_MS), sendMsg3Timer);
//    }
//
//    // --- 阶段 3：发送 Msg3 ---
//    else if (msg == sendMsg3Timer) {
//        EV << "Device: 发送 Msg3。" << endl;
//        Msg3 *m3 = new Msg3("AuthResponse");
//        m3->setBitLength(1376);
//        send(m3, "radio$o");
//    }
//
//    // --- 阶段 4：收到 Msg4，认证完成，并预约下一次认证 ---
//    else if (dynamic_cast<Msg4 *>(msg)) {
//        simtime_t totalDelay = simTime() - authStartTime;
//        EV << "Device: !!! 认证成功 !!! 延迟: " << totalDelay << "s" << endl;
//        delete msg;
//
//        // 【关键改动】：5秒后再次发起下一次认证，形成循环
//        EV << "Device: 5秒后将重新发起认证..." << endl;
//        scheduleAt(simTime() + 5.0, processDoneMsg);
//    }
//    else {
//        delete msg;
//    }
//}
//==========================开始加入丢包率检验==============
//#include "Device.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Device);
//
//Device::Device() {
//    processDoneMsg = nullptr;
//    sendMsg3Timer = nullptr;
//    authTimeoutMsg = nullptr;
//}
//
//Device::~Device() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(sendMsg3Timer);
//    cancelAndDelete(authTimeoutMsg);
//}
//
//bool Device::shouldDrop() {
//    return uniform(0, 1) < lossProb;
//}
//
//void Device::initialize() {
//    processDoneMsg = new cMessage("deviceInitDone");
//    sendMsg3Timer  = new cMessage("deviceSendMsg3");
//    authTimeoutMsg = new cMessage("deviceAuthTimeout");
//
//    lossProb      = par("lossProb").doubleValue();
//    authTimeout   = par("authTimeout");
//    retryInterval = par("retryInterval");
//    cycleInterval = par("cycleInterval");
//
//    totalAuthDelay = SIMTIME_ZERO;
//    authAttempts = 0;
//    authSuccess  = 0;
//    authFail     = 0;
//
//    msgTxAttempts = 0;
//    msgDropped    = 0;
//
//    startAuthCycle();
//}
//
//void Device::startAuthCycle() {
//    authAttempts++;
//    authStartTime = simTime();
//
//    // 10.045ms = 10045us
//    scheduleAt(simTime() + SimTime(10045, SIMTIME_US), processDoneMsg);
//
//    cancelEvent(authTimeoutMsg);
//    scheduleAt(simTime() + authTimeout, authTimeoutMsg);
//}
//
//void Device::onAuthTimeout() {
//    authFail++;
//
//    double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;
//    EV << "Device: AUTH TIMEOUT. fail=" << authFail
//       << " attempts=" << authAttempts
//       << " authLossRate=" << authLossRate * 100 << "%" << endl;
//
//    // retry later
//    scheduleAt(simTime() + retryInterval, processDoneMsg);
//}
//
//void Device::handleMessage(cMessage *msg) {
//
//    // timeout
//    if (msg == authTimeoutMsg) {
//        onAuthTimeout();
//        return;
//    }
//
//    // send Msg1
//    if (msg == processDoneMsg) {
//        authStartTime = simTime();
//        cancelEvent(authTimeoutMsg);
//        scheduleAt(simTime() + authTimeout, authTimeoutMsg);
//
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            EV << "Device: DROP Msg1. msgDropped=" << msgDropped << endl;
//            return;
//        }
//
//        Msg1 *m1 = new Msg1("AuthRequest");
//        m1->setBitLength(1216);
//        send(m1, "radio$o");
//        return;
//    }
//
//    // receive Msg2
//    if (dynamic_cast<Msg2 *>(msg)) {
//        delete msg;
//
//        // 20.892ms = 20892us
//        scheduleAt(simTime() + SimTime(20892, SIMTIME_US), sendMsg3Timer);
//        return;
//    }
//
//    // send Msg3
//    if (msg == sendMsg3Timer) {
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            EV << "Device: DROP Msg3. msgDropped=" << msgDropped << endl;
//            return;
//        }
//
//        Msg3 *m3 = new Msg3("AuthResponse");
//        m3->setBitLength(1376);
//        send(m3, "radio$o");
//        return;
//    }
//
//    // receive Msg4 success
//    if (dynamic_cast<Msg4 *>(msg)) {
//        delete msg;
//
//        cancelEvent(authTimeoutMsg);
//
//        simtime_t oneDelay = simTime() - authStartTime;
//        totalAuthDelay += oneDelay;
//        authSuccess++;
//
//        double avgDelay = (authSuccess > 0) ? (totalAuthDelay.dbl() / (double)authSuccess) : 0.0;
//        double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;
//        double msgLossRate  = (msgTxAttempts > 0) ? (double)msgDropped / (double)msgTxAttempts : 0.0;
//
//        EV << "Device: AUTH SUCCESS. delay=" << oneDelay
//           << " avgDelay=" << avgDelay << "s"
//           << " authLossRate=" << authLossRate * 100 << "%"
//           << " msgLossRate=" << msgLossRate * 100 << "%"
//           << endl;
//
//        // next cycle
//        scheduleAt(simTime() + cycleInterval, processDoneMsg);
//        return;
//    }
//
//    delete msg;
//}
//================换成s========
//#include "Device.h"
//#include "AuthMessages_m.h"
//
//Define_Module(Device);
//
//Device::Device() {
//    processDoneMsg = nullptr;
//    sendMsg3Timer = nullptr;
//    authTimeoutMsg = nullptr;
//}
//
//Device::~Device() {
//    cancelAndDelete(processDoneMsg);
//    cancelAndDelete(sendMsg3Timer);
//    cancelAndDelete(authTimeoutMsg);
//}
//
//bool Device::shouldDrop() {
//    return uniform(0, 1) < lossProb;
//}
//
//void Device::initialize() {
//    processDoneMsg = new cMessage("deviceInitDone");
//    sendMsg3Timer  = new cMessage("deviceSendMsg3");
//    authTimeoutMsg = new cMessage("deviceAuthTimeout");
//
//    lossProb      = par("lossProb").doubleValue();
//    authTimeout   = par("authTimeout");
//    retryInterval = par("retryInterval");
//    cycleInterval = par("cycleInterval");
//
//    totalAuthDelay = SIMTIME_ZERO;
//    authAttempts = 0;
//    authSuccess  = 0;
//    authFail     = 0;
//
//    msgTxAttempts = 0;
//    msgDropped    = 0;
//
//    delayVec.setName("authDelay");
//
//    startAuthCycle();
//}
//
//void Device::startAuthCycle() {
//    authAttempts++;
//    authStartTime = simTime();
//
//    // 10.045ms = 0.010045s
//    scheduleAt(simTime() + SimTime(0.010045), processDoneMsg);
//
//    cancelEvent(authTimeoutMsg);
//    scheduleAt(simTime() + authTimeout, authTimeoutMsg);
//}
//
//void Device::onAuthTimeout() {
//    authFail++;
//
//    double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;
//    EV << "Device: AUTH TIMEOUT. fail=" << authFail
//       << " attempts=" << authAttempts
//       << " authLossRate=" << authLossRate * 100 << "%" << endl;
//
//    scheduleAt(simTime() + retryInterval, processDoneMsg);
//}
//
//void Device::handleMessage(cMessage *msg) {
//
//    if (msg == authTimeoutMsg) {
//        onAuthTimeout();
//        return;
//    }
//
//    if (msg == processDoneMsg) {
//        authStartTime = simTime();
//
//        cancelEvent(authTimeoutMsg);
//        scheduleAt(simTime() + authTimeout, authTimeoutMsg);
//
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            EV << "Device: DROP Msg1. msgDropped=" << msgDropped << endl;
//            return;
//        }
//
//        Msg1 *m1 = new Msg1("AuthRequest");
//        m1->setBitLength(1216);
//        send(m1, "radio$o");
//        return;
//    }
//
//    if (dynamic_cast<Msg2 *>(msg)) {
//        delete msg;
//
//        // 20.892ms = 0.020892s
//        scheduleAt(simTime() + SimTime(0.020892), sendMsg3Timer);
//        return;
//    }
//
//    if (msg == sendMsg3Timer) {
//        msgTxAttempts++;
//        if (shouldDrop()) {
//            msgDropped++;
//            EV << "Device: DROP Msg3. msgDropped=" << msgDropped << endl;
//            return;
//        }
//
//        Msg3 *m3 = new Msg3("AuthResponse");
//        m3->setBitLength(1376);
//        send(m3, "radio$o");
//        return;
//    }
//
//    if (dynamic_cast<Msg4 *>(msg)) {
//        delete msg;
//        cancelEvent(authTimeoutMsg);
//
//        simtime_t oneDelay = simTime() - authStartTime;
//
//        // ★记录每次成功延迟到 vec
//        delayVec.record(oneDelay.dbl());
//
//        totalAuthDelay += oneDelay;
//        authSuccess++;
//
//        double avgDelay = (authSuccess > 0) ? (totalAuthDelay.dbl() / (double)authSuccess) : 0.0;
//        double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;
//        double msgLossRate  = (msgTxAttempts > 0) ? (double)msgDropped / (double)msgTxAttempts : 0.0;
//
//        EV << "Device: AUTH SUCCESS. delay=" << oneDelay
//           << " avgDelay=" << avgDelay << "s"
//           << " authLossRate=" << authLossRate * 100 << "%"
//           << " msgLossRate=" << msgLossRate * 100 << "%"
//           << endl;
//
//        scheduleAt(simTime() + cycleInterval, processDoneMsg);
//        return;
//    }
//
//    delete msg;
//}
//
//// ★仿真结束写 scalar
//void Device::finish() {
//    double avgDelay = (authSuccess > 0) ? (totalAuthDelay.dbl() / (double)authSuccess) : 0.0;
//    double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;
//    double msgLossRate  = (msgTxAttempts > 0) ? (double)msgDropped / (double)msgTxAttempts : 0.0;
//
//    recordScalar("authAttempts", authAttempts);
//    recordScalar("authSuccess", authSuccess);
//    recordScalar("authFail", authFail);
//    recordScalar("avgAuthDelay_s", avgDelay);
//    recordScalar("authLossRate", authLossRate);
//    recordScalar("msgLossRate", msgLossRate);
//}
//==================================加入随机触发=============================================
#include "Device.h"
#include "AuthMessages_m.h"

Define_Module(Device);

Device::Device() {
    startCycleMsg = nullptr;
    sendMsg1Msg = nullptr;
    sendMsg3Timer = nullptr;
    authTimeoutMsg = nullptr;
    msg4ProcessDoneMsg = nullptr;
    pendingMsg4 = nullptr;
}

Device::~Device() {
    cancelAndDelete(startCycleMsg);
    cancelAndDelete(sendMsg1Msg);
    cancelAndDelete(sendMsg3Timer);
    cancelAndDelete(authTimeoutMsg);
    cancelAndDelete(msg4ProcessDoneMsg);
    if (pendingMsg4) delete pendingMsg4;
}

void Device::scheduleNextStart(simtime_t minI, simtime_t maxI) {
    double w = uniform(minI.dbl(), maxI.dbl());
    scheduleAt(simTime() + SimTime(w), startCycleMsg);
}

void Device::initialize() {
    startCycleMsg = new cMessage("startCycle");
    sendMsg1Msg   = new cMessage("sendMsg1");
    sendMsg3Timer = new cMessage("sendMsg3");
    authTimeoutMsg = new cMessage("authTimeout");
    msg4ProcessDoneMsg = new cMessage("msg4Done");

    // params
    authTimeout = par("authTimeout");
    startIntervalMin = par("startIntervalMin");
    startIntervalMax = par("startIntervalMax");
    retryIntervalMin = par("retryIntervalMin");
    retryIntervalMax = par("retryIntervalMax");

    // stats
    totalAuthDelay = SIMTIME_ZERO;
    authAttempts = 0;
    authSuccess = 0;
    authFail = 0;

    delayVec.setName("authDelay");

    // 第一次随机触发
    scheduleNextStart(startIntervalMin, startIntervalMax);
}

void Device::startAuthCycle() {
    authAttempts++;

    // 端到端延迟从这里开始算（包含Msg1生成10.045ms）
    authStartTime = simTime();

    // Msg1 generation: 10.045ms = 0.010045s
    scheduleAt(simTime() + SimTime(0.010045), sendMsg1Msg);

    cancelEvent(authTimeoutMsg);
    scheduleAt(simTime() + authTimeout, authTimeoutMsg);

    EV << "Device: START AUTH cycle, attempts=" << authAttempts << endl;
}

void Device::onAuthTimeout() {
    authFail++;

    double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;
    EV << "Device: AUTH TIMEOUT. fail=" << authFail
       << " attempts=" << authAttempts
       << " authLossRate=" << authLossRate * 100 << "%" << endl;

    // 随机重试
    scheduleNextStart(retryIntervalMin, retryIntervalMax);
}

void Device::handleMessage(cMessage *msg) {

    if (msg == startCycleMsg) {
        startAuthCycle();
        return;
    }

    if (msg == authTimeoutMsg) {
        onAuthTimeout();
        return;
    }

    // send Msg1 after generation delay
    if (msg == sendMsg1Msg) {
        Msg1 *m1 = new Msg1("AuthRequest");
        m1->setBitLength(1216);
        send(m1, "radio$o");
        return;
    }

    // receive Msg2
    if (dynamic_cast<Msg2 *>(msg)) {
        delete msg;

        // process Msg2: 20.892ms = 0.020892s
        scheduleAt(simTime() + SimTime(0.020892), sendMsg3Timer);
        return;
    }

    // send Msg3
    if (msg == sendMsg3Timer) {
        Msg3 *m3 = new Msg3("AuthResponse");
        m3->setBitLength(1376);
        send(m3, "radio$o");
        return;
    }

    // receive Msg4 -> process 0.01ms then success
    if (dynamic_cast<Msg4 *>(msg)) {
        pendingMsg4 = msg;

        // Msg4 processing: 0.01ms = 0.00001s
        scheduleAt(simTime() + SimTime(0.00001), msg4ProcessDoneMsg);
        return;
    }

    // Msg4 processed => success
    if (msg == msg4ProcessDoneMsg) {
        if (pendingMsg4) {
            delete pendingMsg4;
            pendingMsg4 = nullptr;
        }

        cancelEvent(authTimeoutMsg);

        simtime_t oneDelay = simTime() - authStartTime;
        delayVec.record(oneDelay.dbl());

        totalAuthDelay += oneDelay;
        authSuccess++;

        double avgDelay = (authSuccess > 0) ? (totalAuthDelay.dbl() / (double)authSuccess) : 0.0;
        double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;

        // 保留每轮输出
        EV << "Device: AUTH SUCCESS. delay=" << oneDelay
           << " avgDelay=" << avgDelay << "s"
           << " authLossRate=" << authLossRate * 100 << "%"
           << endl;

        // 成功后随机触发下一次认证
        scheduleNextStart(startIntervalMin, startIntervalMax);
        return;
    }

    delete msg;
}

void Device::finish() {
    double avgDelay = (authSuccess > 0) ? (totalAuthDelay.dbl() / (double)authSuccess) : 0.0;
    double authLossRate = (authAttempts > 0) ? (double)authFail / (double)authAttempts : 0.0;

    recordScalar("authAttempts", authAttempts);
    recordScalar("authSuccess", authSuccess);
    recordScalar("authFail", authFail);

    recordScalar("avgAuthDelay_s", avgDelay);
    recordScalar("authLossRate", authLossRate);

    EV << "==== FINAL SUMMARY ====" << endl;
    EV << "attempts=" << authAttempts
       << " success=" << authSuccess
       << " fail=" << authFail << endl;
    EV << "avgDelay=" << avgDelay << "s"
       << " authLossRate=" << authLossRate * 100 << "%"
       << endl;
}










