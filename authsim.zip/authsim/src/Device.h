//#ifndef __AUTHSIM_DEVICE_H
//#define __AUTHSIM_DEVICE_H
//
//#include <omnetpp.h>
//
//using namespace omnetpp;
//
////class Device : public cSimpleModule
////{
////  protected:
////    cMessage *processDoneMsg;
////    simtime_t authStartTime;    // ������֤��ʼʱ��
////  public:
//////      Device(); // ���캯��
//////      virtual ~Device(); // ������
////
////    virtual void initialize() override;
////    virtual void handleMessage(cMessage *msg) override;
////};
//class Device : public cSimpleModule
//{
//  private:
//    cMessage *processDoneMsg;  // ��ʼ������
//    cMessage *sendMsg3Timer;   // ���� Msg2 ������
//    simtime_t authStartTime;   // ��¼��ʼʱ��
//
//  protected:
//    virtual void initialize() override;
//    virtual void handleMessage(cMessage *msg) override;
//
//  public:
//    Device();
//    virtual ~Device();
//};
//===========================4����Ϣ��֤����ҿ�ʼѭ��========================================
//#ifndef __ALOHA_DEVICE_H_
//#define __ALOHA_DEVICE_H_
//
//#include <omnetpp.h>
//
//using namespace omnetpp;
//
//class Device : public cSimpleModule
//{
//  private:
//    cMessage *processDoneMsg;  // ��ʼ/�ظ���֤������
//    cMessage *sendMsg3Timer;   // ���� Msg2 ������
//    simtime_t authStartTime;
//
//  protected:
//    virtual void initialize() override;
//    virtual void handleMessage(cMessage *msg) override;
//
//  public:
//    Device();
//    virtual ~Device();
//};
//
//#endif
////
////#endif
//=================================���붪���ʼ���=================================================
//#ifndef __DEVICE_H
//#define __DEVICE_H
//
//#include <omnetpp.h>
//
//using namespace omnetpp;
//
//class Device : public cSimpleModule
//{
//  public:
//    Device();
//    virtual ~Device();
//
//  protected:
//    virtual void initialize() override;
//    virtual void handleMessage(cMessage *msg) override;
//
//  private:
//    cMessage *processDoneMsg;
//    cMessage *sendMsg3Timer;
//    cMessage *authTimeoutMsg;
//
//    simtime_t authStartTime;
//
//    simtime_t totalAuthDelay;
//    long authAttempts;
//    long authSuccess;
//    long authFail;
//
//    long msgTxAttempts;
//    long msgDropped;
//
//    double lossProb;
//    simtime_t authTimeout;
//    simtime_t retryInterval;
//    simtime_t cycleInterval;
//
//  private:
//    bool shouldDrop();
//    void startAuthCycle();
//    void onAuthTimeout();
//};
//
//#endif
//==========================����s==================================
//#ifndef __DEVICE_H
//#define __DEVICE_H
//
//#include <omnetpp.h>
//using namespace omnetpp;
//
//class Device : public cSimpleModule
//{
//  public:
//    Device();
//    virtual ~Device();
//
//  protected:
//    virtual void initialize() override;
//    virtual void handleMessage(cMessage *msg) override;
//    virtual void finish() override;   // ���������������finish����
//
//  private:
//    cMessage *processDoneMsg;
//    cMessage *sendMsg3Timer;
//    cMessage *authTimeoutMsg;
//
//    simtime_t authStartTime;
//
//    simtime_t totalAuthDelay;
//    long authAttempts;
//    long authSuccess;
//    long authFail;
//
//    long msgTxAttempts;
//    long msgDropped;
//
//    double lossProb;
//    simtime_t authTimeout;
//    simtime_t retryInterval;
//    simtime_t cycleInterval;
//
//    cOutVector delayVec;              // ���������������delayVec����
//
//  private:
//    bool shouldDrop();
//    void startAuthCycle();
//    void onAuthTimeout();
//};
//
//#endif
//================================�����������=============================================
#ifndef __DEVICE_H
#define __DEVICE_H

#include <omnetpp.h>
using namespace omnetpp;

class Device : public cSimpleModule
{
  public:
    Device();
    virtual ~Device();

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void finish() override;

  private:
    cMessage *startCycleMsg;        // ����һ����֤���ڣ����ʱ�䣩
    cMessage *sendMsg1Msg;          // Msg1������ɺ���
    cMessage *sendMsg3Timer;        // Msg2���������Msg3
    cMessage *authTimeoutMsg;       // ��֤��ʱ
    cMessage *msg4ProcessDoneMsg;   // Msg4�������

    cMessage *pendingMsg4;          // �ݴ�Msg4

    simtime_t authStartTime;

    // stats
    simtime_t totalAuthDelay;
    long authAttempts;   // ��֤��������
    long authSuccess;
    long authFail;

    // params
    simtime_t authTimeout;
    simtime_t startIntervalMin;
    simtime_t startIntervalMax;
    simtime_t retryIntervalMin;
    simtime_t retryIntervalMax;

    cOutVector delayVec;

  private:
    void scheduleNextStart(simtime_t minI, simtime_t maxI);
    void startAuthCycle();
    void onAuthTimeout();
};

#endif





