#include "WirelessChannel.h"

Define_Module(WirelessChannel);

WirelessChannel::WirelessChannel() : bitrate(1e6), propagationDelay(0) {}

WirelessChannel::~WirelessChannel() {
    // clean up any remaining transmissions
    for (auto *tx : ongoing) {
        if (tx->endEvent) cancelAndDelete(tx->endEvent);
        if (tx->frame) delete tx->frame;
        delete tx;
    }
    ongoing.clear();
}

void WirelessChannel::initialize() {
    bitrate = par("bitrate").doubleValue();     // bps
    propagationDelay = par("propagationDelay"); // seconds
}

simtime_t WirelessChannel::calcTxDuration(cPacket *pkt) const {
    long bits = pkt ? pkt->getBitLength() : 0;
    if (bitrate <= 0) return SIMTIME_ZERO;
    double sec = (double)bits / bitrate;
    return SimTime(sec);
}

void WirelessChannel::checkCollisionAndMark(Tx *newTx) {
    // Overlap rule: if [start,end] overlaps with any ongoing tx => collision
    for (auto *tx : ongoing) {
        bool overlap = !(newTx->end <= tx->start || newTx->start >= tx->end);
        if (overlap) {
            newTx->collided = true;
            tx->collided = true;
        }
    }
}

void WirelessChannel::finishTransmission(Tx *tx) {
    // remove from ongoing list
    for (auto it = ongoing.begin(); it != ongoing.end(); ++it) {
        if (*it == tx) { ongoing.erase(it); break; }
    }

    // collision => drop (do not deliver)
    if (tx->collided) {
        delete tx->frame;
        tx->frame = nullptr;
        delete tx->endEvent;
        tx->endEvent = nullptr;
        delete tx;
        return;
    }

    // deliver by broadcasting to all nodes except sender
    int n = gateSize("radio");
    for (int i = 0; i < n; ++i) {
        if (i == tx->senderIndex) continue;
        cPacket *copy = tx->frame->dup();
        send(copy, "radio$o", i);
    }

    delete tx->frame;
    tx->frame = nullptr;
    delete tx->endEvent;
    tx->endEvent = nullptr;
    delete tx;
}

void WirelessChannel::handleMessage(cMessage *msg) {

    // self-message: end of a transmission
    if (msg->isSelfMessage()) {
        Tx *tx = (Tx*)msg->getContextPointer();
        finishTransmission(tx);
        return;
    }

    // incoming packet from a node
    cPacket *pkt = check_and_cast<cPacket*>(msg);

    int senderIndex = pkt->getArrivalGate()->getIndex();
    simtime_t dur = calcTxDuration(pkt);

    Tx *newTx = new Tx();
    newTx->start = simTime();
    newTx->end = simTime() + dur;
    newTx->senderIndex = senderIndex;
    newTx->collided = false;
    newTx->frame = pkt;

    cMessage *endEvt = new cMessage("txEnd");
    endEvt->setContextPointer(newTx);
    newTx->endEvent = endEvt;

    // check collision with current ongoing transmissions
    checkCollisionAndMark(newTx);

    // add to ongoing list
    ongoing.push_back(newTx);

    // schedule delivery time (end + propagationDelay)
    scheduleAt(newTx->end + propagationDelay, endEvt);
}
